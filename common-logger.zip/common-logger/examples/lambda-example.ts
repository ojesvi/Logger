// Example: Lambda Function using Common Logger
import { createLogger, extractLambdaCorrelationIds } from '@obs-demo/common-logger';

const logger = createLogger('lambda-orders', 'info');

export const handler = async (event: any, context: any) => {
  try {
    // Extract correlation IDs automatically
    const correlation = extractLambdaCorrelationIds(event, context);
    
    logger.info('Lambda function invoked', { 
      functionName: context.functionName,
      requestId: context.awsRequestId 
    }, {
      correlation: {
        rum_trace_id: correlation.rumTraceId,
        cf_request_id: correlation.cfRequestId,
        apigw_request_id: correlation.apigwRequestId,
      }
    });

    // Process the request
    const body = JSON.parse(event.body || '{}');
    const orderId = body.orderId;
    
    if (!orderId) {
      logger.warn('Missing orderId in request', {}, {
        correlation: {
          rum_trace_id: correlation.rumTraceId,
          cf_request_id: correlation.cfRequestId,
          apigw_request_id: correlation.apigwRequestId,
        }
      });
      
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'Missing orderId' })
      };
    }

    // Simulate processing
    logger.info('Processing order', { orderId }, {
      correlation: {
        rum_trace_id: correlation.rumTraceId,
        cf_request_id: correlation.cfRequestId,
        apigw_request_id: correlation.apigwRequestId,
      }
    });

    // Simulate some work
    await new Promise(resolve => setTimeout(resolve, 100));

    logger.info('Order processed successfully', { 
      orderId,
      processingTime: 100 
    }, {
      correlation: {
        rum_trace_id: correlation.rumTraceId,
        cf_request_id: correlation.cfRequestId,
        apigw_request_id: correlation.apigwRequestId,
      }
    });

    return {
      statusCode: 200,
      body: JSON.stringify({ 
        message: 'Order processed successfully',
        orderId 
      })
    };

  } catch (error) {
    logger.error('Error processing order', { 
      error: error instanceof Error ? error.message : 'Unknown error',
      stack: error instanceof Error ? error.stack : undefined 
    }, {
      correlation: {
        rum_trace_id: extractLambdaCorrelationIds(event, context).rumTraceId,
        cf_request_id: extractLambdaCorrelationIds(event, context).cfRequestId,
        apigw_request_id: extractLambdaCorrelationIds(event, context).apigwRequestId,
      }
    });

    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Internal server error' })
    };
  }
};
