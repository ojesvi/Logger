// Example: ECS Service (Express) using Common Logger
import { createLogger, extractExpressCorrelationIds } from '@obs-demo/common-logger';
import express from 'express';

const logger = createLogger('care-tips-service', 'info');
const app = express();

// Middleware to extract correlation IDs for all requests
app.use((req, res, next) => {
  const correlation = extractExpressCorrelationIds(req);
  
  // Add correlation to request object for easy access
  (req as any).correlation = correlation;
  
  logger.info('Request received', {
    method: req.method,
    url: req.url,
    userAgent: req.headers['user-agent']
  }, {
    correlation: {
      rum_trace_id: correlation.rumTraceId,
      cf_request_id: correlation.cfRequestId,
      alb_trace_id: correlation.albTraceId,
    }
  });
  
  next();
});

// Health check endpoint
app.get('/health', (req, res) => {
  const correlation = (req as any).correlation;
  
  logger.info('Health check requested', {}, {
    correlation: {
      rum_trace_id: correlation.rumTraceId,
      cf_request_id: correlation.cfRequestId,
      alb_trace_id: correlation.albTraceId,
    }
  });
  
  res.json({ status: 'healthy', timestamp: new Date().toISOString() });
});

// Care tips endpoint
app.get('/care-tips', (req, res) => {
  const correlation = (req as any).correlation;
  const category = req.query.category as string;
  
  logger.info('Fetching care tips', { category }, {
    correlation: {
      rum_trace_id: correlation.rumTraceId,
      cf_request_id: correlation.cfRequestId,
      alb_trace_id: correlation.albTraceId,
    }
  });

  try {
    // Simulate database query
    const tips = [
      'Water your plants daily',
      'Ensure adequate sunlight',
      'Check soil moisture regularly',
      'Trim dead leaves'
    ];

    // Filter tips based on category
    const filteredTips = category 
      ? tips.filter(tip => tip.toLowerCase().includes(category.toLowerCase()))
      : tips;

    logger.info('Care tips retrieved successfully', { 
      category,
      tipCount: filteredTips.length 
    }, {
      correlation: {
        rum_trace_id: correlation.rumTraceId,
        cf_request_id: correlation.cfRequestId,
        alb_trace_id: correlation.albTraceId,
      }
    });

    res.json({ 
      tips: filteredTips,
      category,
      count: filteredTips.length 
    });

  } catch (error) {
    logger.error('Error fetching care tips', { 
      error: error instanceof Error ? error.message : 'Unknown error',
      category 
    }, {
      correlation: {
        rum_trace_id: correlation.rumTraceId,
        cf_request_id: correlation.cfRequestId,
        alb_trace_id: correlation.albTraceId,
      }
    });

    res.status(500).json({ 
      error: 'Failed to fetch care tips' 
    });
  }
});

// Submit care question endpoint
app.post('/care-questions', express.json(), (req, res) => {
  const correlation = (req as any).correlation;
  const { question, category } = req.body;
  
  logger.info('Care question submitted', { 
    question: question?.substring(0, 100), // Log first 100 chars
    category 
  }, {
    correlation: {
      rum_trace_id: correlation.rumTraceId,
      cf_request_id: correlation.cfRequestId,
      alb_trace_id: correlation.albTraceId,
    }
  });

  try {
    // Simulate processing the question
    const response = {
      answer: "Thank you for your question. Our experts will review it and provide guidance.",
      questionId: `q_${Date.now()}`,
      category,
      submittedAt: new Date().toISOString()
    };

    logger.info('Care question processed successfully', { 
      questionId: response.questionId,
      category 
    }, {
      correlation: {
        rum_trace_id: correlation.rumTraceId,
        cf_request_id: correlation.cfRequestId,
        alb_trace_id: correlation.albTraceId,
      }
    });

    res.status(201).json(response);

  } catch (error) {
    logger.error('Error processing care question', { 
      error: error instanceof Error ? error.message : 'Unknown error',
      category 
    }, {
      correlation: {
        rum_trace_id: correlation.rumTraceId,
        cf_request_id: correlation.cfRequestId,
        alb_trace_id: correlation.albTraceId,
      }
    });

    res.status(500).json({ 
      error: 'Failed to process care question' 
    });
  }
});

// Error handling middleware
app.use((error: Error, req: express.Request, res: express.Response, next: express.NextFunction) => {
  const correlation = (req as any).correlation;
  
  logger.error('Unhandled error', { 
    error: error.message,
    stack: error.stack,
    url: req.url,
    method: req.method 
  }, {
    correlation: {
      rum_trace_id: correlation?.rumTraceId,
      cf_request_id: correlation?.cfRequestId,
      alb_trace_id: correlation?.albTraceId,
    }
  });

  res.status(500).json({ 
    error: 'Internal server error' 
  });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  logger.info('Care tips service started', { port: PORT });
});
