// Common Winston + OpenTelemetry Logger for All Backend Services
// Usage: import { createLogger, extractCorrelationIds } from '@obs-demo/common-logger';

import winston from 'winston';
import { WinstonInstrumentation } from '@opentelemetry/instrumentation-winston';
import { HttpInstrumentation } from '@opentelemetry/instrumentation-http';
import { registerInstrumentations } from '@opentelemetry/instrumentation';
import { NodeSDK } from '@opentelemetry/sdk-node';

// Initialize OpenTelemetry SDK (once per process)
let isInitialized = false;

function initializeOpenTelemetry() {
  if (isInitialized) return;
  
  try {
    // Initialize OpenTelemetry SDK with HTTP and Winston instrumentation
    const sdk = new NodeSDK({
      instrumentations: [
        new HttpInstrumentation({
          // This reads X-Amzn-Trace-Id headers and creates spans
          requestHook: (span, request) => {
            // Check if request has headers (IncomingMessage has headers, ClientRequest doesn't)
            if ('headers' in request && request.headers) {
              const traceId = request.headers['x-amzn-trace-id'];
              if (traceId) {
                span.setAttributes({
                  'http.trace_id': traceId,
                });
              }
            } 
          },
        }),
        new WinstonInstrumentation({
          // Automatically inject trace_id, span_id, trace_flags into log records
          disableLogCorrelation: false,
        }),
      ],
    });

    sdk.start();
    isInitialized = true;
    console.log('OpenTelemetry SDK initialized successfully');
  } catch (error) {
    console.error('Failed to initialize OpenTelemetry SDK:', error);
  }
}

// Correlation IDs interface
export interface CorrelationIds {
  rumTraceId?: string;
  cfRequestId?: string;
  apigwRequestId?: string;
  xrayTrace?: string; // This is the same as ALB trace ID (X-Amzn-Trace-Id)
  // userId?: string; // PII - generally avoid logging
  requestId?: string;
}

// Log context interface
export interface LogContext {
  service?: string;
  operation?: string;
  duration?: number;
  statusCode?: number;
  error?: string;
  [key: string]: any;
}

// Create logger instance
export function createLogger(serviceName: string, logLevel: string = 'info'): winston.Logger {
  // Initialize OpenTelemetry SDK
  initializeOpenTelemetry();

  // Create Winston logger with structured format
  const logger = winston.createLogger({
    level: logLevel,
    format: winston.format.combine(
      winston.format.timestamp(),
      winston.format.errors({ stack: true }),
      winston.format.json()
    ),
    defaultMeta: {
      service: serviceName,
      environment: process.env.OTEL_RESOURCE_ATTRIBUTES?.match(/deployment\.environment=([^,]+)/)?.[1] || 'unknown',
      region: process.env.OTEL_RESOURCE_ATTRIBUTES?.match(/cloud\.region=([^,]+)/)?.[1] || 'unknown',
    },
    transports: [
      // Console transport for CloudWatch Logs
      new winston.transports.Console({
        format: winston.format.combine(
          winston.format.timestamp(),
          winston.format.printf(({ timestamp, level, message, service, ...meta }) => {
            return JSON.stringify({
              timestamp,
              level,
              message,
              service,
              ...meta
            });
          })
        )
      })
    ],
  });

  return logger;
}

// Helper function to extract correlation IDs from headers
export function extractCorrelationIds(headers: any): CorrelationIds {
  const lowerHeaders: any = {};
  for (const key in headers) {
    lowerHeaders[key.toLowerCase()] = headers[key];
  }
  
  return {
    rumTraceId: lowerHeaders['x-rum-trace-id'] || '',
    cfRequestId: lowerHeaders['x-amz-cf-id'] || '',
    apigwRequestId: lowerHeaders['x-apigw-request-id'] || '',
    xrayTrace: lowerHeaders['x-amzn-trace-id'] || '', // This is the same as ALB trace ID
    // userId removed for PII compliance
    requestId: lowerHeaders['x-request-id'] || lowerHeaders['x-correlation-id'] || ''
  };
}

// Helper function to extract correlation IDs from AWS Lambda context
export function extractLambdaCorrelationIds(event: any, context: any): CorrelationIds {
  const headers = event.headers || {};
  const correlation = extractCorrelationIds(headers);
  
  return {
    ...correlation,
    requestId: context.awsRequestId || correlation.requestId
  };
}

// Helper function to extract correlation IDs from Express request
export function extractExpressCorrelationIds(req: any): CorrelationIds {
  return extractCorrelationIds(req.headers);
}

// Convenience function for logging with correlation IDs
export function logWithCorrelation(
  logger: winston.Logger,
  level: 'info' | 'error' | 'warn' | 'debug',
  message: string,
  context: LogContext = {},
  correlation: CorrelationIds = {}
) {
  // Add correlation IDs to the log context
  const logContext = {
    ...context,
    correlation: {
      rum_trace_id: correlation.rumTraceId || undefined,
      cf_request_id: correlation.cfRequestId || undefined,
      apigw_request_id: correlation.apigwRequestId || undefined,
      xray_trace: correlation.xrayTrace || undefined, // This is the same as ALB trace ID
      // user_id removed for PII compliance
      request_id: correlation.requestId || undefined,
    }
  };

  // Winston will automatically add trace_id, span_id, trace_flags if in a span context
  logger[level](message, logContext);
}

// Export Winston for advanced usage
export { winston };
