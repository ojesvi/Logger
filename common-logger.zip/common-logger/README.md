# Common Winston + OpenTelemetry Logger

A unified logging solution for all backend services with automatic trace correlation and custom correlation IDs.

## Features

- ✅ **Automatic X-Ray trace correlation** via Winston + OpenTelemetry
- ✅ **Custom correlation IDs** (RUM, CloudFront, API Gateway, etc.)
- ✅ **Structured JSON logging** for CloudWatch
- ✅ **Single logger** for Lambda, ECS, and other backend services
- ✅ **TypeScript support** with full type definitions

## Installation

### For Backend Services

```bash
npm install @obs-demo/common-logger
```

### For Local Development

```bash
# Build the logger package
npm install
npm run build

# Create a tarball for local use
npm pack

# Install in your service
npm install obs-demo-common-logger-1.0.0.tgz
```

## Usage

### Lambda Function

```typescript
import { createLogger, extractLambdaCorrelationIds } from '@obs-demo/common-logger';

const logger = createLogger('lambda-orders', 'info');

export const handler = async (event: any, context: any) => {
  // Extract correlation IDs automatically
  const correlation = extractLambdaCorrelationIds(event, context);
  
  // Log with automatic trace correlation + custom correlation IDs
  logger.info('Processing order request', { 
    orderId: event.body.orderId 
  }, {
    correlation: {
      rum_trace_id: correlation.rumTraceId,
      cf_request_id: correlation.cfRequestId,
      apigw_request_id: correlation.apigwRequestId,
    }
  });
  
  return { statusCode: 200, body: 'Success' };
};
```

### ECS Service (Express)

```typescript
import { createLogger, extractExpressCorrelationIds } from '@obs-demo/common-logger';
import express from 'express';

const logger = createLogger('care-tips-service', 'info');
const app = express();

app.get('/care-tips', (req, res) => {
  // Extract correlation IDs automatically
  const correlation = extractExpressCorrelationIds(req);
  
  // Log with automatic trace correlation
  logger.info('Fetching care tips', { 
    category: req.query.category 
  }, {
    correlation: {
      rum_trace_id: correlation.rumTraceId,
      cf_request_id: correlation.cfRequestId,
      alb_trace_id: correlation.albTraceId,
    }
  });
  
  res.json({ tips: ['Water daily', 'Sunlight needed'] });
});
```

## Output Format

```json
{
  "timestamp": "2025-01-13T12:06:50.942Z",
  "level": "info",
  "message": "Processing order request",
  "service": "lambda-orders",
  "orderId": "12345",
  "trace_id": "e21c7a95fff34e04f77c7bd518779621",
  "span_id": "b7589a981fde09f4",
  "trace_flags": "01",
  "correlation": {
    "rum_trace_id": "Root=1-68c49549-0efab52d31c9e5671515d0a4",
    "cf_request_id": "abc123",
    "apigw_request_id": "def456"
  }
}
```

## Correlation IDs

| ID | Source | Purpose |
|----|--------|---------|
| `trace_id` | OpenTelemetry (automatic) | X-Ray trace correlation |
| `span_id` | OpenTelemetry (automatic) | Current span identifier |
| `rum_trace_id` | Frontend RUM | User session correlation |
| `cf_request_id` | CloudFront headers | Edge correlation |
| `apigw_request_id` | API Gateway headers | Gateway correlation |
| `xray_trace` | X-Ray/ALB headers | Same as ALB trace ID (X-Amzn-Trace-Id) |

**Note**: `xray_trace` is the same as ALB trace ID - both use the `X-Amzn-Trace-Id` header.

## Environment Variables

Set these environment variables for proper service identification:

```bash
OTEL_SERVICE_NAME=my-service-name
OTEL_RESOURCE_ATTRIBUTES=deployment.environment=production,cloud.region=eu-central-1
```

## API Reference

#### `createLogger(serviceName: string, logLevel?: string)`

Creates a Winston logger instance with OpenTelemetry instrumentation.

#### `extractLambdaCorrelationIds(event: any, context: any)`

Extracts correlation IDs from Lambda event and context.

#### `extractExpressCorrelationIds(req: any)`

Extracts correlation IDs from Express request headers.

#### `extractCorrelationIds(headers: any)`

Generic function to extract correlation IDs from any headers object.

#### `logWithCorrelation(logger, level, message, context?, correlation?)`

Convenience function for logging with correlation IDs.
